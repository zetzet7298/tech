<?php

use App\Core\Adapters\Theme;

return array(
    // Refer to config/global/menu.php

    // Horizontal menu
    'horizontal' => array(
        // Dashboard
        array(
            'title'   => 'Dashboard',
            'path'    => 'admin',
            'classes' => array('item' => 'me-lg-1'),
        ),

        // // Resources
        // array(
        //     'title'      => 'Resources',
        //     'classes'    => array('item' => 'menu-lg-down-accordion me-lg-1', 'arrow' => 'd-lg-none'),
        //     'attributes' => array(
        //         'data-kt-menu-trigger'   => "click",
        //         'data-kt-menu-placement' => "bottom-start",
        //     ),
        //     'sub'        => array(
        //         'class' => 'menu-sub-lg-down-accordion menu-sub-lg-dropdown menu-rounded-0 py-lg-4 w-lg-225px',
        //         'items' => array(

        //             // Documentation
        //             array(
        //                 'title' => 'Documentation',
        //                 'icon'  => theme()->getSvgIcon("demo1/media/icons/duotune/abstract/abs027.svg", "svg-icon-2"),
        //                 'path'  => 'documentation/getting-started/overview',
        //             ),

        //             // Changelog
        //             array(
        //                 'title' => 'Changelog',
        //                 'icon'  => theme()->getSvgIcon("demo1/media/icons/duotune/general/gen005.svg", "svg-icon-2"),
        //                 'path'  => 'documentation/getting-started/changelog',
        //             ),
        //         ),
        //     ),
        // ),

        // Mega menu
        // array(
        //     'title'      => 'Mega Menu',
        //     'classes'    => array('item' => 'menu-lg-down-accordion me-lg-1', 'arrow' => 'd-lg-none'),
        //     'attributes' => array(
        //         'data-kt-menu-trigger'   => "click",
        //         'data-kt-menu-placement' => "bottom-start",
        //     ),
        //     'sub'        => array(
        //         'class' => 'menu-sub-lg-down-accordion menu-sub-lg-dropdown w-100 w-lg-600px p-5 p-lg-5',
        //         'view'  => 'layout/header/_mega-menu',
        //     ),
        // ),
    ),
);
