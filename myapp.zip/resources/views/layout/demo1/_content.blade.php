<!--begin::Container-->
<div id="kt_content_container" class="{{ theme()->printHtmlClasses('content-container', false) }}">
    {{ $slot }}
</div>
<!--end::Container-->
