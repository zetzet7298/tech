<!--begin::Scrolltop-->
<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
    {!! theme()->getSvgIcon("icons/duotune/arrows/arr066.svg") !!}
</div>
<!--end::Scrolltop-->
