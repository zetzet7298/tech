<!--begin::Action--->
<td class="symbol symbol-50px"></td>
<div class="symbol symbol-50px">
    <img src="{{ productImage($model->image) }}" class="card-img-top img-fluid " alt="...">
</div>
</td>
<!--end::Action--->
