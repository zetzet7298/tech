<div class="hotline-phone-ring-wrap">
<div class="hotline-phone-ring">
    <div class="hotline-phone-ring-circle"></div>
    <div class="hotline-phone-ring-circle-fill"></div>
    <div class="hotline-phone-ring-img-circle"> <a href="tel:+84942704480" class="pps-btn-img">
        <img src="assets/media/phone.png" alt="Phone">
        </a> </div>
</div>
</div><?php /**PATH /var/www/resources/views/layout/_call.blade.php ENDPATH**/ ?>