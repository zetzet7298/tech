<?php if (isset($component)) { $__componentOriginal7442783a15dff2b0d32f2947a462c2e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2 = $attributes; } ?>
<?php $component = App\View\Components\BaseLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('scripts'); ?>
        <script>
            $(document).ready(function() {
        // Kiểm tra nếu kích thước màn hình lớn hơn hoặc bằng 768px (desktop)
        if (window.matchMedia("(min-width: 768px)").matches) {
            var uriValue = $('input[name="uri"]').val();
            if (uriValue != '') {
                // Lấy vị trí top của phần tử có ID cụ thể
                var targetOffset = $(`#${uriValue}`).offset().top;

                // Cuộn trang đến vị trí của phần tử với hiệu ứng animate
                $('html, body').animate({
                    scrollTop: targetOffset
                }, 1); // Thời gian cuộn (miliseconds)
            }
        }
    });
        </script>
    <?php $__env->stopSection(); ?>
    <input name="uri" type="hidden" value="<?php echo e($uri); ?>" />
    <div class="d-flex flex-column flex-root py-5" id="khach-san-binh-hung">
        <div class="mb-lg-n15 position-relative z-index-2">
            <!--begin::Container-->
            <div class="container">
                <!--begin::Card-->
                <div class="card" style="filter: drop-shadow(0px 0px 40px rgba(68, 81, 96, 0.08))">
                    <!--begin::Card body-->
                    <div class="card-body p-lg-20">
                        <div class="g-overview">
                            <h2 class="fs-md-2hx fs-lg-2hx fs-1 text-p mb-1" id="khach-san"
                                data-kt-scroll-offset="{default: 100, lg: 150}">Khách Sạn Hồng Nhàn Tại Bình Hưng</h2>
                            <div class="description">
                                <p><strong>Khách Sạn Hồng Nhàn</strong>&nbsp;nằm ngay trước mặt&nbsp;<strong>Đảo Bình
                                        Hưng</strong>, có thể nói đây là khách sạn đẹp nhất và chất lượng phục vụ tốt
                                    nhất
                                    tại đây. Quý khách có thể cảm nhận được&nbsp;sự rộn ràng của người dân biển, cảm
                                    nhận
                                    được gió trời lồng lộng, gần gũi với thiên nhiên. Các phòng có ban công và cửa sổ,
                                    tiện
                                    nghi phòng đầy đủ không kém trên đất liền, đảm bảo&nbsp;cho quý khách một kỳ nghĩ
                                    tuyệt
                                    vời.</p>

                                <p><span style="color:#000033"><span style="font-size:16px"><strong>Điểm Nổi Bật Của
                                                Khách
                                                Sạn :&nbsp;</strong></span></span></p>

                                <ul>
                                    <li>Cách <strong>Bãi Kinh</strong> khoảng 15 phút đi tàu</li>
                                    <li>Cách&nbsp;<strong>Chùa&nbsp;Long Hưng</strong> 250 M</li>
                                    <li>Cách <strong>Bãi Đá Trứng</strong> 800 M</li>
                                    <li>Cách <strong>Hải Đăng Hòn Chút</strong> 1 Km</li>
                                </ul>
                            </div>
                        </div>
                        <!--begin::Tabs wrapper-->
                        <div class="d-flex flex-center mb-1 mb-lg-10">
                            <div>
                                <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                                    <li class="nav-item">
                                        <a class="nav-link active text-gray-700" data-bs-toggle="tab"
                                            href="#hongnhan1"><span class="badge badge-light-info">Xem kshn
                                                1</span></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#hongnhan2"><span
                                                class="badge badge-light-info">Xem kshn 2</span></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#hongnhan3"><span
                                                class="badge badge-light-info">Xem kshn 3</span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!--end::Tabs wrapper-->
                        <!--begin::Tabs content-->
                        <div class="tab-content">
                            <!--begin::Tab pane-->
                            <div class="tab-pane fade show active" id="hongnhan1">
                                <!--begin::Row-->
                                <div class="tns tns-default">
                                    <!--begin::Slider-->
                                    <div data-tns="true" data-tns-loop="true" data-tns-swipe-angle="false"
                                        data-tns-speed="1000" data-tns-autoplay="true" data-tns-autoplay-timeout="18000"
                                        data-tns-controls="true" data-tns-nav="false" data-tns-items="1"
                                        data-tns-center="false" data-tns-dots="false"
                                        data-tns-responsive="{1200: {items: 3}, 992: {items: 2}}"
                                        data-tns-prev-button="#kt_team_slider_prev2"
                                        data-tns-next-button="#kt_team_slider_next2">
                                        <!--begin::Youtube-->
                                        <a class="d-block bgi-no-repeat bgi-size-cover bgi-position-center rounded position-relative min-h-225px"
                                            style="background-image: url('assets/media/ks1/cover.png'); filter: brightness(80%);"
                                            data-fslightbox="lightbox-youtube"
                                            href="https://www.youtube.com/watch?v=9zBPvIoQvnQ">
                                            <!--begin::Icon-->
                                            <img src="assets/media/svg/misc/video-play.svg"
                                                style="filter: brightness(150%);"
                                                class="position-absolute top-50 start-50 translate-middle"
                                                alt="" />
                                            <!--end::Icon-->
                                        </a>
                                        <!--end::Youtube-->
                                        <?php for($i = 1; $i <= 9; $i++): ?>
                                            <!--begin::Item-->
                                            <div class="square mx-auto">
                                                <a class="d-block overlay my-item" data-fslightbox="lightbox-basic2"
                                                    href="assets/media/ks1/<?php echo e($i); ?>.jpg">
                                                    <!--begin::Image-->
                                                    <div class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded 
min-h-225px min-h-md-650px min-h-lg-350px
"
                                                        style="background-image:url('assets/media/ks1/<?php echo e($i); ?>.jpg')">
                                                    </div>
                                                    <!--end::Image-->

                                                    <!--begin::Action-->
                                                    <div
                                                        class="overlay-layer card-rounded bg-dark bg-opacity-25 shadow">
                                                        <img src="assets/media/zoom.png"
                                                            class="w-25px fs-3x opacity-75 shadow" alt="Zoom icon" />
                                                    </div>
                                                    <!--end::Action-->
                                                </a>
                                            </div>
                                        <?php endfor; ?>

                                        <!--end::Item-->
                                    </div>
                                    <!--end::Slider-->

                                    <!--begin::Slider button-->
                                    <button class="btn btn-icon btn-active-color-primary" id="kt_team_slider_prev2">
                                        <span class="svg-icon svg-icon-3x">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none">
                                                <path
                                                    d="M11.2657 11.4343L15.45 7.25C15.8642 6.83579 15.8642 6.16421 15.45 5.75C15.0358 5.33579 14.3642 5.33579 13.95 5.75L8.40712 11.2929C8.01659 11.6834 8.01659 12.3166 8.40712 12.7071L13.95 18.25C14.3642 18.6642 15.0358 18.6642 15.45 18.25C15.8642 17.8358 15.8642 17.1642 15.45 16.75L11.2657 12.5657C10.9533 12.2533 10.9533 11.7467 11.2657 11.4343Z"
                                                    fill="black" />
                                            </svg>
                                        </span>
                                    </button>
                                    <!--end::Slider button-->

                                    <!--begin::Slider button-->
                                    <button class="btn btn-icon btn-active-color-primary" id="kt_team_slider_next2">
                                        <span class="svg-icon svg-icon-3x">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none">
                                                <path
                                                    d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z"
                                                    fill="black" />
                                            </svg>
                                        </span>
                                    </button>
                                    <!--end::Slider button-->
                                    <div class="text-center mt-4">
                                        <a class="d-block overlay my-item fs-8 btn btn-success w-125px w-md-200px w-lg-200px mx-auto"
                                            data-fslightbox="lightbox-basic2" href="assets/media/ks1/1.jpg">Xem toàn
                                            bộ</a>
                                    </div>
                                </div>
                                <!--end::Row-->
                            </div>
                            <!--end::Tab pane-->
                            <!--begin::Tab pane-->
                            <div class="tab-pane fade" id="hongnhan2">
                                <!--begin::Row-->
                                <div class="tns tns-default">
                                    <!--begin::Slider-->
                                    <div data-tns="true" data-tns-loop="true" data-tns-swipe-angle="false"
                                        data-tns-speed="1000" data-tns-autoplay="true"
                                        data-tns-autoplay-timeout="18000" data-tns-controls="true"
                                        data-tns-nav="false" data-tns-items="1" data-tns-center="false"
                                        data-tns-dots="false"
                                        data-tns-responsive="{1200: {items: 3}, 992: {items: 2}}"
                                        data-tns-prev-button="#kt_team_slider_prev3"
                                        data-tns-next-button="#kt_team_slider_next3">
                                        <?php for($i = 1; $i <= 8; $i++): ?>
                                            <!--begin::Youtube-->
                                            <a class="d-block bgi-no-repeat bgi-size-cover bgi-position-center rounded position-relative min-h-225px"
                                                style="background-image: url('assets/media/ks2/cover.png'); filter: brightness(80%);"
                                                data-fslightbox="lightbox-youtube"
                                                href="https://www.youtube.com/watch?v=a7VVAT3B9Hw">
                                                <!--begin::Icon-->
                                                <img src="assets/media/svg/misc/video-play.svg"
                                                    style="filter: brightness(150%);"
                                                    class="position-absolute top-50 start-50 translate-middle"
                                                    alt="" />
                                                <!--end::Icon-->
                                            </a>
                                            <!--end::Youtube-->
                                            <!--begin::Item-->
                                            <div class="square mx-auto w-md-325px h-md-400px">
                                                <a class="d-block overlay my-item" data-fslightbox="lightbox-basic3"
                                                    href="assets/media/ks2/<?php echo e($i); ?>.jpg">
                                                    <!--begin::Image-->
                                                    <div class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded 
min-h-225px min-h-md-650px min-h-lg-350px
"
                                                        style="background-image:url('assets/media/ks2/<?php echo e($i); ?>.jpg')">
                                                    </div>
                                                    <!--end::Image-->

                                                    <!--begin::Action-->
                                                    <div
                                                        class="overlay-layer card-rounded bg-dark bg-opacity-25 shadow">
                                                        <img src="assets/media/zoom.png"
                                                            class="w-25px fs-3x opacity-75 shadow" alt="Zoom icon" />
                                                    </div>
                                                    <!--end::Action-->
                                                </a>
                                            </div>
                                        <?php endfor; ?>

                                        <!--end::Item-->
                                    </div>
                                    <!--end::Slider-->

                                    <!--begin::Slider button-->
                                    <button class="btn btn-icon btn-active-color-primary" id="kt_team_slider_prev3">
                                        <span class="svg-icon svg-icon-3x">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none">
                                                <path
                                                    d="M11.2657 11.4343L15.45 7.25C15.8642 6.83579 15.8642 6.16421 15.45 5.75C15.0358 5.33579 14.3642 5.33579 13.95 5.75L8.40712 11.2929C8.01659 11.6834 8.01659 12.3166 8.40712 12.7071L13.95 18.25C14.3642 18.6642 15.0358 18.6642 15.45 18.25C15.8642 17.8358 15.8642 17.1642 15.45 16.75L11.2657 12.5657C10.9533 12.2533 10.9533 11.7467 11.2657 11.4343Z"
                                                    fill="black" />
                                            </svg>
                                        </span>
                                    </button>
                                    <!--end::Slider button-->

                                    <!--begin::Slider button-->
                                    <button class="btn btn-icon btn-active-color-primary" id="kt_team_slider_next3">
                                        <span class="svg-icon svg-icon-3x">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none">
                                                <path
                                                    d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z"
                                                    fill="black" />
                                            </svg>
                                        </span>
                                    </button>
                                    <!--end::Slider button-->
                                    <div class="text-center mt-4">
                                        <a class="d-block overlay my-item fs-8 btn btn-success w-125px w-md-200px w-lg-200px mx-auto"
                                            data-fslightbox="lightbox-basic3" href="assets/media/ks2/1.jpg">Xem toàn
                                            bộ</a>
                                    </div>
                                </div>
                                <!--end::Row-->
                            </div>
                            <!--end::Tab pane-->
                            <!--begin::Tab pane-->
                            <div class="tab-pane fade" id="hongnhan3">
                                <!--begin::Row-->
                                <div class="tns tns-default">
                                    <!--begin::Slider-->
                                    <div data-tns="true" data-tns-loop="true" data-tns-swipe-angle="false"
                                        data-tns-speed="1000" data-tns-autoplay="true"
                                        data-tns-autoplay-timeout="18000" data-tns-controls="true"
                                        data-tns-nav="false" data-tns-items="1" data-tns-center="false"
                                        data-tns-dots="false"
                                        data-tns-responsive="{1200: {items: 3}, 992: {items: 2}}"
                                        data-tns-prev-button="#kt_team_slider_prev4"
                                        data-tns-next-button="#kt_team_slider_next4">
                                        <?php for($i = 1; $i <= 6; $i++): ?>
                                            <!--begin::Youtube-->
                                            <a class="d-block bgi-no-repeat bgi-size-cover bgi-position-center rounded position-relative min-h-225px"
                                                style="background-image: url('assets/media/ks3/cover.png'); filter: brightness(80%);"
                                                data-fslightbox="lightbox-youtube"
                                                href="https://www.youtube.com/watch?v=ODe97UF4eA8">
                                                <!--begin::Icon-->
                                                <img src="assets/media/svg/misc/video-play.svg"
                                                    style="filter: brightness(150%);"
                                                    class="position-absolute top-50 start-50 translate-middle"
                                                    alt="" />
                                                <!--end::Icon-->
                                            </a>
                                            <!--end::Youtube-->
                                            <!--begin::Item-->
                                            <div class="square mx-auto w-md-325px h-md-400px">
                                                <a class="d-block overlay my-item" data-fslightbox="lightbox-basic4"
                                                    href="assets/media/ks3/<?php echo e($i); ?>.jpg">
                                                    <!--begin::Image-->
                                                    <div class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded 
min-h-225px min-h-md-650px min-h-lg-350px
"
                                                        style="background-image:url('assets/media/ks3/<?php echo e($i); ?>.jpg')">
                                                    </div>
                                                    <!--end::Image-->

                                                    <!--begin::Action-->
                                                    <div
                                                        class="overlay-layer card-rounded bg-dark bg-opacity-25 shadow">
                                                        <img src="assets/media/zoom.png"
                                                            class="w-25px fs-3x opacity-75 shadow" alt="Zoom icon" />
                                                    </div>
                                                    <!--end::Action-->
                                                </a>
                                            </div>
                                        <?php endfor; ?>

                                        <!--end::Item-->
                                    </div>
                                    <!--end::Slider-->

                                    <!--begin::Slider button-->
                                    <button class="btn btn-icon btn-active-color-primary" id="kt_team_slider_prev4">
                                        <span class="svg-icon svg-icon-3x">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none">
                                                <path
                                                    d="M11.2657 11.4343L15.45 7.25C15.8642 6.83579 15.8642 6.16421 15.45 5.75C15.0358 5.33579 14.3642 5.33579 13.95 5.75L8.40712 11.2929C8.01659 11.6834 8.01659 12.3166 8.40712 12.7071L13.95 18.25C14.3642 18.6642 15.0358 18.6642 15.45 18.25C15.8642 17.8358 15.8642 17.1642 15.45 16.75L11.2657 12.5657C10.9533 12.2533 10.9533 11.7467 11.2657 11.4343Z"
                                                    fill="black" />
                                            </svg>
                                        </span>
                                    </button>
                                    <!--end::Slider button-->

                                    <!--begin::Slider button-->
                                    <button class="btn btn-icon btn-active-color-primary" id="kt_team_slider_next4">
                                        <span class="svg-icon svg-icon-3x">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none">
                                                <path
                                                    d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z"
                                                    fill="black" />
                                            </svg>
                                        </span>
                                    </button>
                                    <!--end::Slider button-->
                                    <div class="text-center mt-4">
                                        <a class="d-block overlay my-item fs-8 btn btn-success w-125px w-md-200px w-lg-200px mx-auto"
                                            data-fslightbox="lightbox-basic4" href="assets/media/ks3/1.jpg">Xem toàn
                                            bộ</a>
                                    </div>
                                </div>
                                <!--end::Row-->
                            </div>
                            <!--end::Tab pane-->
                        </div>
                        <!--end::Tabs content-->
                    </div>
                    <!--end::Card body-->
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $attributes = $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $component = $__componentOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/pages/khachsan.blade.php ENDPATH**/ ?>