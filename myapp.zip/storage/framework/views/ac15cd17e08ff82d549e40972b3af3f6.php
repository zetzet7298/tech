<!--begin::Container-->
<div id="kt_content_container" class="<?php echo e(theme()->printHtmlClasses('content-container', false)); ?>">
    <?php echo e($slot); ?>

</div>
<!--end::Container-->
<?php /**PATH /var/www/resources/views/layout/demo1/_content.blade.php ENDPATH**/ ?>