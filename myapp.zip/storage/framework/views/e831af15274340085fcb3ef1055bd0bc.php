<div class="brands">
    <div class="container">
          <div class="owl-carousel owl-carousel6-brands">
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/canon.jpg')); ?>" alt="canon" title="canon"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/esprit.jpg')); ?>" alt="esprit" title="esprit"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/gap.jpg')); ?>" alt="gap" title="gap"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/next.jpg')); ?>" alt="next" title="next"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/puma.jpg')); ?>" alt="puma" title="puma"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/zara.jpg')); ?>" alt="zara" title="zara"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/canon.jpg')); ?>" alt="canon" title="canon"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/esprit.jpg')); ?>" alt="esprit" title="esprit"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/gap.jpg')); ?>" alt="gap" title="gap"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/next.jpg')); ?>" alt="next" title="next"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/puma.jpg')); ?>" alt="puma" title="puma"></a>
            <a href="shop-product-list.html"><img src="<?php echo e(asset('img/brands/zara.jpg')); ?>" alt="zara" title="zara"></a>
          </div>
      </div>
</div><?php /**PATH /var/www/resources/views/admin/layout/_brand.blade.php ENDPATH**/ ?>