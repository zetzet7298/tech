



<!-- ==================== Start cursor ==================== -->
<div class="mouse-cursor cursor-outer"></div>
<div class="mouse-cursor cursor-inner"></div>
<!-- ==================== End cursor ==================== -->
<div id="hcontainer">
    <div class="header ">
        <div class="center-layout">
            <a href="https://mikotech.vn" class="himg" rel="doffolow">
                
            </a>
            <div class="header__right ">
                <div class="header__nav_container">
                    <ul id="menu-menu-chinh" class="header__nav">
                        <li id="menu-item-385"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-264 current_page_item menu-item-385">
                            <a href="<?php echo e(route('trangchu')); ?>" aria-current="page">Trang chủ</a>
                        </li>
                        <li id="menu-item-391"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-391"><a
                                href="<?php echo e(route('gioithieu')); ?>">Giới thiệu</a></li>
                        <li id="menu-item-386"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-386">
                            <a href="<?php echo e(route('dichvu')); ?>">Dịch Vụ</a>
                            <ul class="sub-menu">
                                <li id="menu-item-382"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-382"><a
                                        href="https://mikotech.vn/thiet-ke-website/">Thiết kế Website</a></li>
                            </ul>
                        </li>
                        <li id="menu-item-1658"
                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1658"><a
                                href="<?php echo e(route('duan')); ?>">Dự án</a></li>
                        <li id="menu-item-390"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-390"><a
                                href="<?php echo e(route('nhansu')); ?>">Nhân sự</a></li>
                        <li id="menu-item-392"
                            class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-392">
                            <a href="<?php echo e(route('tintuc')); ?>">Tin tức</a>
                            <ul class="sub-menu">
                                <li id="menu-item-393"
                                    class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-393">
                                    <a href="">Kiến Thức SEO</a>
                                    <ul class="sub-menu">
                                        <li id="menu-item-35516"
                                            class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-35516">
                                            <a href="">Thuật Ngữ SEO</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div> <a class="effect-link header__button " href="<?php echo e(route('lienhe')); ?>">Liên hệ</a>
                
            </div>
        </div>
    </div>
    <a href="javascript:;" class="hmmenu__button">
        <span></span>
        <span></span>
        <span></span>
    </a>
    <div class="hmmenu">
        <div class="hmmenu__header">
            
        </div>
        <div class="hmmenu__main">
            <div class="hmmenu__nav_container">
                <ul id="menu-menu-chinh-1" class="hmmenu__nav">
                    <li
                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-264 current_page_item menu-item-385">
                        <a href="<?php echo e(route('trangchu')); ?>" aria-current="page">Trang chủ</a>
                    </li>
                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-391"><a
                            href="<?php echo e(route('gioithieu')); ?>">Giới thiệu</a></li>
                    <li
                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-386">
                        <a href="<?php echo e(route('dichvu')); ?>">Dịch Vụ</a>
                        <ul class="sub-menu">
                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-382"><a
                                    href="">Thiết kế Website</a></li>
                        </ul>
                    </li>
                    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1658"><a
                            href="<?php echo e(route('duan')); ?>">Dự án</a></li>
                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-390"><a
                            href="<?php echo e(route('nhansu')); ?>">Nhân sự</a></li>
                    <li
                        class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-392">
                        <a href="<?php echo e(route('tintuc')); ?>">Tin tức</a>
                        <ul class="sub-menu">
                            <li
                                class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-393">
                                <a href="">Kiến Thức SEO</a>
                                <ul class="sub-menu">
                                </ul>
                            </li>
                        </ul>
            </div>
        </div>
    </div><?php /**PATH /var/www/resources/views/layout/_header.blade.php ENDPATH**/ ?>