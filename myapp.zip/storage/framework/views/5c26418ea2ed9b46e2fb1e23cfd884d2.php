<div class="steps-block steps-block-red">
    <div class="container">
      <div class="row">
        <div class="col-md-4 steps-block-col">
          <i class="fa fa-truck"></i>
          <div>
            <h2>Free shipping</h2>
            <em>Express delivery withing 3 days</em>
          </div>
          <span>&nbsp;</span>
        </div>
        <div class="col-md-4 steps-block-col">
          <i class="fa fa-gift"></i>
          <div>
            <h2>Daily Gifts</h2>
            <em>3 Gifts daily for lucky customers</em>
          </div>
          <span>&nbsp;</span>
        </div>
        <div class="col-md-4 steps-block-col">
          <i class="fa fa-phone"></i>
          <div>
            <h2>477 505 8877</h2>
            <em>24/7 customer care available</em>
          </div>
        </div>
      </div>
    </div>
  </div><?php /**PATH /var/www/resources/views/admin/layout/_step_block.blade.php ENDPATH**/ ?>