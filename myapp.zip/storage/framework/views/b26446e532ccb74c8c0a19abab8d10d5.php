<?php
    $toolbarButtonMarginClass = "ms-1 ms-lg-3";
    $toolbarButtonHeightClass = "w-40px h-40px";
    $toolbarUserAvatarHeightClass = "symbol-40px";
    $toolbarButtonIconSizeClass = "svg-icon-1";
?>


<div class="d-flex align-items-stretch flex-shrink-0">
    
    <div class="d-flex align-items-stretch <?php echo e($toolbarButtonMarginClass); ?>">
        <?php echo e(theme()->getView('partials/search/_base')); ?>

    </div>
    

    
    <div class="d-flex align-items-center <?php echo e($toolbarButtonMarginClass); ?>">
        
        <div class="btn btn-icon btn-active-light-primary <?php echo e($toolbarButtonHeightClass); ?>" id="kt_activities_toggle">
            <?php echo theme()->getSvgIcon("icons/duotune/general/gen032.svg", $toolbarButtonIconSizeClass); ?>

        </div>
        
    </div>
    

    
    <div class="d-flex align-items-center <?php echo e($toolbarButtonMarginClass); ?>">
        
        <div class="btn btn-icon btn-active-light-primary position-relative <?php echo e($toolbarButtonHeightClass); ?>" data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
            <?php echo theme()->getSvgIcon("icons/duotune/communication/com012.svg", $toolbarButtonIconSizeClass); ?>


            <span class="bullet bullet-dot bg-success h-6px w-6px position-absolute translate-middle top-0 start-50 animation-blink">
            </span>
        </div>
        <?php echo e(theme()->getView('partials/topbar/_notifications-menu')); ?>

        
    </div>
    

    
    <div class="d-flex align-items-center <?php echo e($toolbarButtonMarginClass); ?>">
        
        <div class="btn btn-icon btn-active-light-primary <?php echo e($toolbarButtonHeightClass); ?>" data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
            <?php echo theme()->getSvgIcon("icons/duotune/general/gen025.svg", $toolbarButtonIconSizeClass); ?>

        </div>
        <?php echo e(theme()->getView('partials/topbar/_quick-links-menu')); ?>

        
    </div>
    

    
    <?php if(Auth::check()): ?>
        <div class="d-flex align-items-center <?php echo e($toolbarButtonMarginClass); ?>" id="kt_header_user_menu_toggle">
            
            <div class="cursor-pointer symbol <?php echo e($toolbarUserAvatarHeightClass); ?>" data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
                <img src="<?php echo e(auth()->user()->avatarUrl); ?>" alt="metronic"/>
            </div>
            <?php echo e(theme()->getView('partials/topbar/_user-menu')); ?>

            
        </div>
    <?php endif; ?>
    

    
    <?php if(theme()->getOption('layout', 'header/left') === 'menu'): ?>
        <div class="d-flex align-items-center d-lg-none ms-2 me-n3" data-bs-toggle="tooltip" title="Show header menu">
            <div class="btn btn-icon btn-active-light-primary" id="kt_header_menu_mobile_toggle">
                <?php echo theme()->getSvgIcon("icons/duotune/text/txt001.svg", "svg-icon-1"); ?>

            </div>
        </div>
    <?php endif; ?>
    
</div>

<?php /**PATH /var/www/resources/views/layout/demo1/topbar/_base.blade.php ENDPATH**/ ?>