<?php
// Table rows
$tableRows = [
    [
        'user' => [
            'image' => 'avatars/150-11.jpg',
            'name' => 'Ana Simmons',
            'skills' => 'HTML, JS, ReactJS',
        ],
        'company' => [
            'name' => 'Intertico',
            'skills' => 'Web, UI/UX Design',
        ],
        'progress' => [
            'value' => '50',
            'color' => 'primary',
        ],
    ],
    [
        'user' => [
            'image' => 'avatars/150-3.jpg',
            'name' => 'Jessie Clarcson',
            'skills' => 'C#, ASP.NET, MS SQL',
        ],
        'company' => [
            'name' => 'Agoda',
            'skills' => 'Houses & Hotels',
        ],
        'progress' => [
            'value' => '70',
            'color' => 'danger',
        ],
    ],
    [
        'user' => [
            'image' => 'avatars/150-4.jpg',
            'name' => 'Lebron Wayde',
            'skills' => 'PHP, Laravel, VueJS',
        ],
        'company' => [
            'name' => 'RoadGee',
            'skills' => 'Transportation',
        ],
        'progress' => [
            'value' => '60',
            'color' => 'success',
        ],
    ],
    [
        'user' => [
            'image' => 'avatars/150-5.jpg',
            'name' => 'Natali Goodwin',
            'skills' => 'Python, PostgreSQL, ReactJS',
        ],
        'company' => [
            'name' => 'The Hill',
            'skills' => 'Insurance',
        ],
        'progress' => [
            'value' => '50',
            'color' => 'warning',
        ],
    ],
    [
        'user' => [
            'image' => 'avatars/150-6.jpg',
            'name' => 'Kevin Leonard',
            'skills' => 'HTML, JS, ReactJS',
        ],
        'company' => [
            'name' => 'RoadGee',
            'skills' => 'Art Director',
        ],
        'progress' => [
            'value' => '90',
            'color' => 'info',
        ],
    ],
];
?>

<!--begin::Tables Widget 9-->
<div class="card <?php echo e($class); ?>">
    <!--begin::Header-->
    <div class="card-header border-0 pt-5">
        <h3 class="card-title align-items-start flex-column">
            <span class="card-label fw-bolder fs-3 mb-1">Phản hồi từ khách hàng</span>
        </h3>

        <div class="card-toolbar" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-trigger="hover"
            title="Nhấp vào để thêm feedback">
            <a href="<?php echo e(route('feedbacks.create')); ?>" class="btn btn-sm btn-light-primary">
                <?php echo theme()->getSvgIcon('icons/duotune/arrows/arr075.svg', 'svg-icon-3'); ?>

                Tạo feedback mới
            </a>
        </div>
    </div>
    <!--end::Header-->

    <!--begin::Body-->
    <div class="card-body py-3">
        <!--begin::Table container-->
        <div class="table-responsive">
            <!--begin::Table-->
            <table class="table table-row-dashed table-row-gray-300 align-middle gs-0 gy-4">
                <!--begin::Table head-->
                <thead>
                    <tr class="fw-bolder text-muted">
                        
                        <th class="min-w-150px">Tên khách hàng</th>
                        <th class="min-w-140px">Tên công ty KH</th>
                        <th class="min-w-120px">Nội dung</th>
                        <th class="min-w-100px text-end">Actions</th>
                    </tr>
                </thead>
                <!--end::Table head-->

                <!--begin::Table body-->
                <tbody>
                    <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            

                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-45px me-5">
                                        <img src="<?php echo e(display_image($row->image)); ?>"
                                            alt="" />
                                    </div>
                                    <div class="d-flex justify-content-start flex-column">
                                        <a href="#"
                                            class="text-dark fw-bolder text-hover-primary fs-6"><?php echo e($row->name); ?></a>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-45px me-5">
                                        <img src="<?php echo e(asset(theme()->getMediaUrlPath() . $row['user']['image'])); ?>"
                                            alt="" />
                                    </div>
                                    <div class="d-flex justify-content-start flex-column">
                                        <a href="#"
                                            class="text-dark fw-bolder text-hover-primary fs-6"><?php echo e($row['user']['name']); ?></a>

                                        <span
                                            class="text-muted fw-bold text-muted d-block fs-7"><?php echo e($row['user']['skills']); ?></span>
                                    </div>
                                </div>
                            </td>

                            <td>
                                <a href="#"
                                    class="text-dark fw-bolder text-hover-primary d-block fs-6"><?php echo e($row['company']['name']); ?></a>
                                <span
                                    class="text-muted fw-bold text-muted d-block fs-7"><?php echo e($row['company']['skills']); ?></span>
                            </td>

                            <td class="text-end">
                                <a href="#"
                                    class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                    <?php echo theme()->getSvgIcon('icons/duotune/general/gen019.svg', 'svg-icon-3'); ?>

                                </a>

                                <a href="#"
                                    class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                    <?php echo theme()->getSvgIcon('icons/duotune/art/art005.svg', 'svg-icon-3'); ?>

                                </a>

                                <a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                                    <?php echo theme()->getSvgIcon('icons/duotune/general/gen027.svg', 'svg-icon-3'); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <!--end::Table body-->
            </table>
            <!--end::Table-->
        </div>
        <!--end::Table container-->
    </div>
    <!--begin::Body-->
</div>
<!--end::Tables Widget 9-->
<?php /**PATH /var/www/resources/views/admin/feedbacks/list.blade.php ENDPATH**/ ?>