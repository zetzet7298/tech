<!--begin::Header-->
<div id="kt_header" style="" class="header <?php echo e(theme()->printHtmlClasses('header', false)); ?> align-items-stretch" <?php echo e(theme()->printHtmlAttributes('header')); ?>>
	<!--begin::Container-->
	<div class="<?php echo e(theme()->printHtmlClasses('header-container', false)); ?> d-flex align-items-stretch justify-content-between">
		

		<!--begin::Wrapper-->
		<div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1">
			<!--begin::Navbar-->
			<?php if(theme()->getOption('layout', 'header/left') === 'menu'): ?>
				<div class="d-flex align-items-stretch" id="kt_header_nav">
                    <?php echo e(theme()->getView('layout/header/_menu')); ?>

				</div>
			<?php elseif(theme()->getOption('layout', 'header/left') === 'page-title'): ?>
				<div class="d-flex align-items-center" id="kt_header_nav">
					<?php echo e(theme()->getView('layout/page-title/_' . theme()->getOption('layout', 'page-title/layout'))); ?>

				</div>
			<?php endif; ?>
			<!--end::Navbar-->

			
		</div>
		<!--end::Wrapper-->
	</div>
	<!--end::Container-->
</div>
<!--end::Header-->
<?php /**PATH /var/www/resources/views/layout/demo1/header/_base.blade.php ENDPATH**/ ?>