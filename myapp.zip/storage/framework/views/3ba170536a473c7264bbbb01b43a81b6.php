<?php
    $logoFileName = 'logo-1-dark.svg';

    if (theme()->getOption('layout', 'aside/theme') === 'light') {
        $logoFileName = 'logo-1.svg';
    }
?>


<div
    id="kt_aside"
    class="aside <?php echo e(theme()->printHtmlClasses('aside', false)); ?>"
    data-kt-drawer="true"
    data-kt-drawer-name="aside"
    data-kt-drawer-activate="{default: true, lg: false}"
    data-kt-drawer-overlay="true"
    data-kt-drawer-width="{default:'200px', '300px': '250px'}"
    data-kt-drawer-direction="start"
    data-kt-drawer-toggle="#kt_aside_mobile_toggle"
>

    
    <div class="aside-logo flex-column-auto" id="kt_aside_logo">
        
        <a href="<?php echo e(theme()->getPageUrl('admin')); ?>">
            <img alt="Logo" src="<?php echo e(asset(theme()->getMediaUrlPath() . 'logos/' . $logoFileName)); ?>" class="h-25px logo"/>
        </a>
        

        <?php if(theme()->getOption('layout', 'aside/minimize') === true): ?>
            
            <div id="kt_aside_toggle" class="btn btn-icon w-auto px-0 btn-active-color-primary aside-toggle"
                 data-kt-toggle="true"
                 data-kt-toggle-state="active"
                 data-kt-toggle-target="body"
                 data-kt-toggle-name="aside-minimize"
            >

                <?php echo theme()->getSvgIcon("icons/duotune/arrows/arr080.svg", "svg-icon-1 rotate-180"); ?>

            </div>
            
        <?php endif; ?>
    </div>
    

    
    <div class="aside-menu flex-column-fluid">
        <?php echo e(theme()->getView('layout/aside/_menu')); ?>

    </div>
    

    
    
    
</div>

<?php /**PATH /var/www/resources/views/layout/demo1/aside/_base.blade.php ENDPATH**/ ?>