<!--begin::Toolbar-->
<div class="toolbar" id="kt_toolbar">
    <!--begin::Container-->
    <div id="kt_toolbar_container" class="<?php echo e(theme()->printHtmlClasses('toolbar-container', false)); ?> d-flex flex-stack">
        <?php if(theme()->getOption('layout', 'page-title/display') && theme()->getOption('layout', 'header/left') !== 'page-title'): ?>
            <?php echo e(theme()->getView('layout/page-title/_default')); ?>

        <?php endif; ?>

		<!--begin::Actions-->
        <div class="d-flex align-items-center py-1">
            <!--begin::Wrapper-->
            <div class="me-4">
                <!--begin::Menu-->
                
                <!--end::Menu-->
            </div>
            <!--end::Wrapper-->

            <!--begin::Wrapper-->
            
            <!--end::Wrapper-->
        </div>
		<!--end::Actions-->
    </div>
    <!--end::Container-->
</div>
<!--end::Toolbar-->
<?php /**PATH /var/www/resources/views/layout/demo1/toolbars/_toolbar-1.blade.php ENDPATH**/ ?>