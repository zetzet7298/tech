<?php if (isset($component)) { $__componentOriginal965465ad15296dd131d2163328808a42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal965465ad15296dd131d2163328808a42 = $attributes; } ?>
<?php $component = App\View\Components\BaseAuthLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BaseAuthLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!--begin::Col-->
    <div class="col-xl-12">
        <!--begin::Tables Widget 9-->
<div class="card card-xxl-stretch mb-5 mb-xl-8">
    <!--begin::Header-->
    <div class="card-header border-0 pt-5">
        <h3 class="card-title align-items-start flex-column">
            <span class="card-label fw-bolder fs-3 mb-1">Giải pháp</span>
        </h3>

        <div class="card-toolbar" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-trigger="hover"
            title="Nhấp vào để thêm feedback">
            <a href="<?php echo e(route('solutions.create')); ?>" class="btn btn-sm btn-light-primary">
                <?php echo theme()->getSvgIcon('icons/duotune/arrows/arr075.svg', 'svg-icon-3'); ?>

                Tạo giải pháp mới
            </a>
        </div>
    </div>
    <!--end::Header-->

    <!--begin::Body-->
    <div class="card-body py-3">
        <!--begin::Table container-->
        <div class="table-responsive">
            <!--begin::Table-->
            <table class="table table-row-dashed table-row-gray-300 align-middle gs-0 gy-4">
                <!--begin::Table head-->
                <thead>
                    <tr class="fw-bolder text-muted">
                        
                        <th class="min-w-150px">Tiêu đề</th>
                        <th class="min-w-140px">Ảnh</th>
                        <th class="min-w-120px">Mô tả</th>
                        <th class="min-w-50px">Vị trí</th>
                        <th class="min-w-100px text-end">Actions</th>
                    </tr>
                </thead>
                <!--end::Table head-->

                <!--begin::Table body-->
                <tbody>
                    <?php $__currentLoopData = $solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            

                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="d-flex justify-content-start flex-column">
                                        <a href="#"
                                            class="text-dark fw-bolder text-hover-primary fs-6"><?php echo e($row->title); ?></a>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-75px me-5">
                                        <img src="<?php echo e(display_image($row->image)); ?>"
                                            alt="" />
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span
                                class="fw-bold text-gray-800 d-block fs-7"><?php echo e(limitString($row->description, 150)); ?></span>
                            </td>
                            <td>
                                <span
                                class="fw-bold text-gray-800 d-block fs-7"><?php echo e($row->index); ?></span>
                            </td>

                            <td class="text-end">
                                

                                <a href="<?php echo e(route('solutions.edit', ['solution' => $row->id])); ?>"
                                    class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                    <?php echo theme()->getSvgIcon('icons/duotune/art/art005.svg', 'svg-icon-3'); ?>

                                </a>

                                <a href="<?php echo e(route('solutions.destroy', ['solution' => $row->id])); ?>" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm"
                                onclick="return confirm('Bạn chắc chắn muốn xóa?');"
                                >
                                    <?php echo theme()->getSvgIcon('icons/duotune/general/gen027.svg', 'svg-icon-3'); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <!--end::Table body-->
            </table>
            <!--end::Table-->
        </div>
        <!--end::Table container-->
    </div>
    <!--begin::Body-->
</div>
<!--end::Tables Widget 9-->

    </div>
    <!--end::Col-->
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal965465ad15296dd131d2163328808a42)): ?>
<?php $attributes = $__attributesOriginal965465ad15296dd131d2163328808a42; ?>
<?php unset($__attributesOriginal965465ad15296dd131d2163328808a42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal965465ad15296dd131d2163328808a42)): ?>
<?php $component = $__componentOriginal965465ad15296dd131d2163328808a42; ?>
<?php unset($__componentOriginal965465ad15296dd131d2163328808a42); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/admin/solutions/index.blade.php ENDPATH**/ ?>