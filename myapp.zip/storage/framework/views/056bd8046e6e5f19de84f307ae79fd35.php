<?php if (isset($component)) { $__componentOriginal7442783a15dff2b0d32f2947a462c2e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2 = $attributes; } ?>
<?php $component = App\View\Components\BaseLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('scripts'); ?>
        <script>
            $(document).ready(function() {
                var uriValue = $('input[name="uri"]').val();
                if (uriValue != '') {
                    // Lấy vị trí top của phần tử có ID cụ thể
                    var targetOffset = $(`#${uriValue}`).offset().top;

                    // Cuộn trang đến vị trí của phần tử với hiệu ứng animate
                    $('html, body').animate({
                        scrollTop: targetOffset
                    }, 1); // Thời gian cuộn (miliseconds)
                }

            });
        </script>
    <?php $__env->stopSection(); ?>
    <!--begin::Main-->
    <input name="uri" type="hidden" value="<?php echo e($uri); ?>" />
    <div class="d-flex flex-column flex-root">
<!--begin::Statistics Section-->
<div class="mt-sm-n10">
    <!--begin::Wrapper-->
    <div class="pb-7 pt-8 landing-dark-bg">
        <!--begin::Container-->
        <div class="container">
            <div class="text-center text-p">
    <!--begin::Title-->
    <h2 class=" fw-boldest fs-md-2hx fs-lg-2hx fs-1">
        Du Lịch Bình Hưng - Trải Nghiệm Tuyệt Vời Tại Hòn Đảo Thiên Đường
    </h2>
    <p class="fs-7 text-p">Với 14 năm kinh nghiệm tổ chức tour Bình Hưng cho hơn 8.000 khách du lịch mỗi năm. Hồng Nhàn cam kết mang đến cho bạn trải nghiệm tuyệt vời nhất!</p>
    <!--end::Title-->
            </div>
                                        
            <!--begin::Slider-->
            <div class="tns tns-default">
                <div id="animatedBox" class="tns tns-default mb-lg-3 mb-md-3 box">
                    <!--begin::Wrapper-->
                    <div data-tns="true" data-tns-loop="true" data-tns-swipe-angle="false" data-tns-speed="1000"
                        data-tns-autoplay="true" data-tns-autoplay-timeout="36000" data-tns-controls="true"
                        data-tns-nav="false" data-tns-items="1" data-tns-center="false" data-tns-dots="false"
                        data-tns-prev-button="#kt_team_slider_prev" data-tns-next-button="#kt_team_slider_next"
                        data-tns-responsive="{1200: {items: 3}, 992: {items: 2}}">
                       
                        <?php for($i = 1; $i <= 9; $i++): ?>
                            <!--begin::Item-->
                            <div class="square mx-auto">
                                <a class="d-block overlay my-item" data-fslightbox="lightbox-basic"
                                    href="assets/media/tongquan/gioi-thieu-binh-hung-<?php echo e($i); ?>.jpg" aria-label="Xem ảnh Giới thiệu Bình Hưng <?php echo e($i); ?>" role="button">
                                    <!--begin::Image-->
                                    <div class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded min-h-275px min-h-md-650px min-h-lg-350px"
                                        style="background-image:url('assets/media/tongquan/gioi-thieu-binh-hung-<?php echo e($i); ?>.jpg')"
                                        aria-label="Giới thiệu Bình Hưng <?php echo e($i); ?>">
                                    </div>
                                    <!--end::Image-->
                                    <!--begin::Action-->
                                    <div class="overlay-layer card-rounded bg-dark bg-opacity-25 shadow">
                                        <img src="assets/media/zoom.png"
                                            class="w-25px fs-3x opacity-75 shadow" alt="Zoom icon" />
                                    </div>
                                    <!--end::Action-->
                                </a>
                            </div>
                            <!--end::Item-->
                        <?php endfor; ?>
                         <!--begin::Youtube-->
                         <a class="d-block bgi-no-repeat bgi-size-cover bgi-position-center rounded position-relative min-h-225px"
                         style="background-image: url('assets/media/gioithieu/gioi-thieu-binh-hung.jpg'); filter: brightness(80%);"
                         data-fslightbox="lightbox-youtube"
                         href="https://www.youtube.com/watch?v=snS95Yoof18"
                         aria-label="Giới thiệu Bình Hưng" role="button">
                         <!--begin::Icon-->
                         <img src="assets/media/svg/misc/video-play.svg" style="filter: brightness(150%);"
                             class="position-absolute top-50 start-50 translate-middle" alt="Play video icon" />
                         <!--end::Icon-->
                     </a>
                     <!--end::Youtube-->
                    </div>
                    <!--end::Wrapper-->
                    <!--begin::Button-->
                    <button class="btn btn-icon btn-active-color-primary" id="kt_team_slider_prev" aria-label="Previous slide">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr074.svg-->
                        <span class="svg-icon svg-icon-3x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                viewBox="0 0 24 24" fill="none">
                                <path
                                    d="M11.2657 11.4343L15.45 7.25C15.8642 6.83579 15.8642 6.16421 15.45 5.75C15.0358 5.33579 14.3642 5.33579 13.95 5.75L8.40712 11.2929C8.01659 11.6834 8.01659 12.3166 8.40712 12.7071L13.95 18.25C14.3642 18.6642 15.0358 18.6642 15.45 18.25C15.8642 17.8358 15.8642 17.1642 15.45 16.75L11.2657 12.5657C10.9533 12.2533 10.9533 11.7467 11.2657 11.4343Z"
                                    fill="black" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </button>
                    <!--end::Button-->
                    <!--begin::Button-->
                    <button class="btn btn-icon btn-active-color-primary" id="kt_team_slider_next" aria-label="Next slide">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr071.svg-->
                        <span class="svg-icon svg-icon-3x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                viewBox="0 0 24 24" fill="none">
                                <path
                                    d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z"
                                    fill="black" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </button>
                    <!--end::Button-->
                </div>
            </div>
            <!--end::Slider-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Wrapper-->
    <!--begin::Curve bottom-->
    <div id="lich-trinh-binh-hung" class="landing-curve landing-dark-color">
        <svg viewBox="15 12 1470 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M0 11C3.93573 11.3356 7.85984 11.6689 11.7725 12H1488.16C1492.1 11.6689 1496.04 11.3356 1500 11V12H1488.16C913.668 60.3476 586.282 60.6117 11.7725 12H0V11Z"
                fill="currentColor"></path>
        </svg>
    </div>
    <!--end::Curve bottom-->
</div>
<!--end::Statistics Section-->
        <!--begin::Statistics Section-->
      
        <!--end::Statistics Section-->
        
        <!--end::Projects Section-->
        <div class="mt-sm-n10">
            
            <!--begin::Wrapper-->
            <div class="pb-15 pt-18 ">
                <!--begin::Container-->
                <div class="container">
                    <!--begin::Heading-->
                    <div class="text-center mt-15 mb-18" id="achievements"
                        data-kt-scroll-offset="{default: 100, lg: 150}">
                        <!--begin::Title-->
                        <h2 class="fs-md-2hx fs-lg-2hx fs-1 text-p fw-boldest mb-1">Tour Bình Hưng của Hồng Nhàn </h3>
                            <!--end::Title-->
                            <!--begin::Description-->
                            <p class="fs-5 text-gray-800 fw-boldest">Hồng Nhàn luôn cam kết mang đến những trải nghiệm
                                chất lượng nhất cho khách hàng</p>
                            <!--end::Description-->
                    </div>
                    <!--end::Heading-->
                    <!--begin::Statistics-->
                    <div class="d-flex flex-center">
                        <!--begin::Items-->
                        <div class="d-flex flex-wrap flex-center justify-content-lg-between mb-15 mx-auto w-xl-900px">
                            <!--begin::Item-->
                            <div
                                class="octagon d-flex flex-column flex-center h-200px w-200px h-lg-250px w-lg-250px m-3 h-200px w-200px bg-body mx-2">
                                <div class="text-center">
                                    <!--begin::Symbol-->
                                    <!--begin::Svg Icon | path: icons/duotune/graphs/gra008.svg-->
                                    <span class="svg-icon svg-icon-2tx svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none">
                                            <rect x="2" y="2" width="9" height="9" rx="2"
                                                fill="black"></rect>
                                            <rect opacity="0.3" x="13" y="2" width="9" height="9"
                                                rx="2" fill="black"></rect>
                                            <rect opacity="0.3" x="13" y="13" width="9" height="9"
                                                rx="2" fill="black"></rect>
                                            <rect opacity="0.3" x="2" y="13" width="9" height="9"
                                                rx="2" fill="black"></rect>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <!--end::Symbol-->
                                    <!--begin::Info-->
                                    <div class="mb-0">
                                        <!--begin::Value-->
                                        <div class="fs-lg-2hx fs-2x fw-bolder text-p d-flex flex-center">
                                            <div class="min-w-70px" data-kt-countup-duration="10"
                                                data-kt-countup="true" data-kt-countup-value="1">0</div>

                                        </div>
                                        <!--end::Value-->
                                        <!--begin::Label-->
                                        <span class="text-gray-800 fw-boldest fs-5 lh-0">Vị trí đắc địa nhất đảo</span>
                                        <!--end::Label-->
                                    </div>
                                    <!--end::Info-->
                                </div>

                            </div>
                            <!--end::Item-->
                            <!--begin::Item-->
                            <div
                                class="octagon d-flex flex-column flex-center h-200px w-200px h-lg-250px w-lg-250px m-3 h-200px w-200px bg-body mx-2">
                                <div class="text-center">
                                    <!--begin::Symbol-->
                                    <!--begin::Svg Icon | path: icons/duotune/general/gen025.svg-->
                                    <span class="svg-icon svg-icon-2tx svg-icon-success">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none">
                                            <path
                                                d="M13 10.9128V3.01281C13 2.41281 13.5 1.91281 14.1 2.01281C16.1 2.21281 17.9 3.11284 19.3 4.61284C20.7 6.01284 21.6 7.91285 21.9 9.81285C22 10.4129 21.5 10.9128 20.9 10.9128H13Z"
                                                fill="black"></path>
                                            <path opacity="0.3"
                                                d="M13 12.9128V20.8129C13 21.4129 13.5 21.9129 14.1 21.8129C16.1 21.6129 17.9 20.7128 19.3 19.2128C20.7 17.8128 21.6 15.9128 21.9 14.0128C22 13.4128 21.5 12.9128 20.9 12.9128H13Z"
                                                fill="black"></path>
                                            <path opacity="0.3"
                                                d="M11 19.8129C11 20.4129 10.5 20.9129 9.89999 20.8129C5.49999 20.2129 2 16.5128 2 11.9128C2 7.31283 5.39999 3.51281 9.89999 3.01281C10.5 2.91281 11 3.41281 11 4.01281V19.8129Z"
                                                fill="black"></path>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <!--end::Symbol-->
                                    <!--begin::Info-->
                                    <div class="mb-0">
                                        <!--begin::Value-->
                                        <div class="fs-lg-2hx fs-2x fw-bolder text-p d-flex flex-center">
                                            <div class="min-w-70px" data-kt-countup-duration="5"
                                                data-kt-countup="true" data-kt-countup-value="14">0</div>
                                        </div>
                                        <!--end::Value-->
                                        <!--begin::Label-->
                                        <span class="text-gray-800 fw-boldest fs-5 lh-0">Năm Kinh Nghiệm Làm
                                            Tour</span>
                                        <!--end::Label-->
                                    </div>
                                </div>

                                <!--end::Info-->
                            </div>
                            <!--end::Item-->

                            <!--begin::Item-->
                            <div
                                class="octagon d-flex flex-column flex-center h-200px w-200px h-lg-250px w-lg-250px m-3 h-200px w-200px bg-body mx-2">
                                <div class="text-center">
                                    <!--begin::Symbol-->
                                    <!--begin::Svg Icon | path: icons/duotune/ecommerce/ecm002.svg-->
                                    <span class="svg-icon svg-icon-2tx svg-icon-info">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none">
                                            <path
                                                d="M21 10H13V11C13 11.6 12.6 12 12 12C11.4 12 11 11.6 11 11V10H3C2.4 10 2 10.4 2 11V13H22V11C22 10.4 21.6 10 21 10Z"
                                                fill="black"></path>
                                            <path opacity="0.3"
                                                d="M12 12C11.4 12 11 11.6 11 11V3C11 2.4 11.4 2 12 2C12.6 2 13 2.4 13 3V11C13 11.6 12.6 12 12 12Z"
                                                fill="black"></path>
                                            <path opacity="0.3"
                                                d="M18.1 21H5.9C5.4 21 4.9 20.6 4.8 20.1L3 13H21L19.2 20.1C19.1 20.6 18.6 21 18.1 21ZM13 18V15C13 14.4 12.6 14 12 14C11.4 14 11 14.4 11 15V18C11 18.6 11.4 19 12 19C12.6 19 13 18.6 13 18ZM17 18V15C17 14.4 16.6 14 16 14C15.4 14 15 14.4 15 15V18C15 18.6 15.4 19 16 19C16.6 19 17 18.6 17 18ZM9 18V15C9 14.4 8.6 14 8 14C7.4 14 7 14.4 7 15V18C7 18.6 7.4 19 8 19C8.6 19 9 18.6 9 18Z"
                                                fill="black"></path>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <!--end::Symbol-->
                                    <!--begin::Info-->
                                    <div class="mb-0">
                                        <!--begin::Value-->
                                        <div class="fs-lg-2hx fs-2x fw-bolder text-p d-flex flex-center">
                                            <div class="min-w-70px" data-kt-countup-duration="3"
                                                data-kt-countup="true" data-kt-countup-value="8248+"></div>
                                        </div>
                                        <!--end::Value-->
                                        <!--begin::Label-->
                                        <span class="text-gray-800 fw-boldest fs-5 lh-0">Lượt đặt tour hàng năm</span>
                                        <!--end::Label-->
                                    </div>
                                    <!--end::Info-->
                                </div>

                            </div>
                            <!--end::Item-->
                        </div>
                        <!--end::Items-->
                    </div>
                    <!--end::Statistics-->
                </div>
            </div>
            <!--begin::Curve top-->
            <div class="landing-curve" style="color: #13263c">
                <svg viewBox="15 -1 1470 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M1 48C4.93573 47.6644 8.85984 47.3311 12.7725 47H1489.16C1493.1 47.3311 1497.04 47.6644 1501 48V47H1489.16C914.668 -1.34764 587.282 -1.61174 12.7725 47H1V48Z"
                        fill="currentColor"></path>
                </svg>
            </div>
            <!--end::Curve top-->
        </div>
        <!--end::Main-->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $attributes = $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $component = $__componentOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/pages/index.blade.php ENDPATH**/ ?>