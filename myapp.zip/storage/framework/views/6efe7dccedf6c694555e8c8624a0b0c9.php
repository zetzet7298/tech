<?php if (isset($component)) { $__componentOriginal7442783a15dff2b0d32f2947a462c2e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2 = $attributes; } ?>
<?php $component = App\View\Components\BaseLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('scripts'); ?>
        <script>
$(document).ready(function() {
        // Kiểm tra nếu kích thước màn hình lớn hơn hoặc bằng 768px (desktop)
        if (window.matchMedia("(min-width: 768px)").matches) {
            var uriValue = $('input[name="uri"]').val();
            if (uriValue != '') {
                // Lấy vị trí top của phần tử có ID cụ thể
                var targetOffset = $(`#${uriValue}`).offset().top;

                // Cuộn trang đến vị trí của phần tử với hiệu ứng animate
                $('html, body').animate({
                    scrollTop: targetOffset
                }, 1); // Thời gian cuộn (miliseconds)
            }
        }
    });
        </script>
    <?php $__env->stopSection(); ?>
    <input name="uri" type="hidden" value="<?php echo e($uri); ?>" />
    <div class="d-flex flex-column flex-root py-5" id="lich-trinh-binh-hung">
        <!--begin::How It Works Section-->
        <div class="mb-n10 mb-lg-n20 z-index-2">
            <!--begin::Container-->
            <div class="container">
                

                <!--begin::Heading-->
                <div class="mb-17 mt-7">
                    <!--begin::Card-->
                    <div class="card" style="filter: drop-shadow(0px 0px 40px rgba(68, 81, 96, 0.08))">
                        <!--begin::Card body-->
                        <div class="card-body p-lg-20">
                            <div class="card-header d-flex flex-column align-items-center min-h-40px mb-5">
                                <!--begin::Title-->
                                <h2 class="text-center text-p fw-boldest fs-md-2hx fs-lg-2hx fs-1">
                                    Lịch Trình Tour Bình Hưng
                                </h2>
                                <p class="fs-8 text-p">Có thể thay đổi khi trao đổi</p>
                                <!--end::Title-->
                            </div>

                            <div class="d-flex flex-column align-items-center">
                                <div>
                                    <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                                        <li class="nav-item">
                                            <a class="nav-link active text-gray-700" data-bs-toggle="tab"
                                                href="#kt_tab_pane_1"><span class="badge badge-light-info">Xem Tour
                                                    Trong Ngày</span></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-bs-toggle="tab" href="#kt_tab_pane_2"><span
                                                    class="badge badge-light-info">Xem Tour 2 ngày 1 đêm</span></a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" id="kt_tab_pane_1">
                                        <!--begin::Card-->
                                        <div class="card card-bordered bg-light">
                                            <div
                                                class="card-header justify-content-end ribbon ribbon-start ribbon-clip">
                                                <div class="ribbon-label">
                                                    Tour trong ngày chỉ <?php echo e(number_format(490000)); ?>đ
                                                    <span class="ribbon-inner bg-info"></span>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <!--begin::Text-->
                                                <!--end::Heading-->
                                                <div class="timeline-label">
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">8h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-warning fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Text-->
                                                        <div class="timeline-content text-gray-800 fw-bolder ps-3">Đón
                                                            khách tại Bãi
                                                            Kinh. Di
                                                            chuyển
                                                            bằng tàu về nhà bè</div>
                                                        <!--end::Text-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">8h30
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">
                                                            <div class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                Bắt
                                                                đầu khám phá
                                                                đảo BÌNH HƯNG – Vương quốc tôm hùm</div>
                                                            <div class="d-flex align-items-center collapsible toggle mb-0 collapsed"
                                                                data-bs-toggle="collapse" data-bs-target="#kt_job"
                                                                aria-expanded="false">
                                                                <!--begin::Icon-->
                                                                <div
                                                                    class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen036.svg-->
                                                                    <span
                                                                        class="svg-icon toggle-on svg-icon-primary svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="6.0104" y="10.9247" width="12"
                                                                                height="2" rx="1"
                                                                                fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
                                                                    <span class="svg-icon toggle-off svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="10.8891" y="17.8033" width="12"
                                                                                height="2" rx="1"
                                                                                transform="rotate(-90 10.8891 17.8033)"
                                                                                fill="black"></rect>
                                                                            <rect x="6.01041" y="10.9247" width="12"
                                                                                height="2" rx="1"
                                                                                fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                </div>
                                                                <!--end::Icon-->
                                                                <!--begin::Title-->
                                                                <div
                                                                    class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                    Bao gồm</div>
                                                                <!--end::Title-->
                                                            </div>
                                                            <div id="kt_job" class="fs-6 ms-1" style="">
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tàu đáy
                                                                            kính đưa khách
                                                                            đi tham quan và lặn ngắm san hô ở Hòn Sam
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tắm
                                                                            biển tại bãi Cây Me
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Có phát
                                                                            phao và kính lặn cho mỗi khách</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                            </div>

                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">11h30
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-primary fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">
                                                            <div class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                Quay về bè nổi ăn
                                                                trưa</div>
                                                            <div class="d-flex align-items-center collapsible toggle mb-0 collapsed"
                                                                data-bs-toggle="collapse" data-bs-target="#thucdon"
                                                                aria-expanded="false">
                                                                <!--begin::Icon-->
                                                                <div
                                                                    class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen036.svg-->
                                                                    <span
                                                                        class="svg-icon toggle-on svg-icon-primary svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="6.0104" y="10.9247" width="12"
                                                                                height="2" rx="1"
                                                                                fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
                                                                    <span class="svg-icon toggle-off svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="10.8891" y="17.8033"
                                                                                width="12" height="2"
                                                                                rx="1"
                                                                                transform="rotate(-90 10.8891 17.8033)"
                                                                                fill="black"></rect>
                                                                            <rect x="6.01041" y="10.9247"
                                                                                width="12" height="2"
                                                                                rx="1" fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                </div>
                                                                <!--end::Icon-->
                                                                <!--begin::Title-->
                                                                <div
                                                                    class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                    Thực đơn gồm
                                                                </div>
                                                                <!--end::Title-->
                                                            </div>
                                                            <div id="thucdon" class="fs-6 ms-1" style="">
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Mực
                                                                            sống nướng muối ớt
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cá
                                                                            nướng giấy bạc
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cầu gai
                                                                            nướng trứng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Hàu
                                                                            nướng mỡ hành</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tôm hùm
                                                                            nướng (1con/người)</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cơm
                                                                            chiên trứng
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cháo
                                                                            hải sản</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">3 loại
                                                                            ốc hấp</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Ghẹ hấp
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tráng
                                                                            miệng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                            </div>

                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">12h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bold text-gray-800 ps-3">Khách
                                                            nghỉ ngơi tại nhà bè
                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">14h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-primary fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Text-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">Tàu
                                                            chở khách vào đảo tham quan bãi đá trứng
                                                        </div>
                                                        <!--end::Text-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">15h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bold text-gray-800 ps-3">Tàu
                                                            chở khách quay về đất liền. Kết thúc tour.</div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->


                                                </div>
                                                <!--end::Text-->
                                            </div>
                                        </div>
                                        <!--end::Card-->

                                    </div>
                                    <div class="tab-pane fade" id="kt_tab_pane_2">
                                        <div class="card card-bordered bg-light">
                                            <div
                                                class="card-header justify-content-end ribbon ribbon-start ribbon-clip">
                                                <div class="ribbon-label">
                                                    Tour 2 ngày 1 đêm chỉ từ <?php echo e(number_format(1300000)); ?>đ
                                                    <span class="ribbon-inner bg-info"></span>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <!--begin::Text-->
                                                <!--end::Heading-->
                                                <div class="timeline-label">
                                                    <span class="badge badge-square badge-primary"
                                                        style="padding:5px;">NGÀY 1</span>
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">8h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-warning fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Text-->
                                                        <div class="timeline-content text-gray-800 fw-bolder ps-3">Đón
                                                            khách tại Bãi
                                                            Kinh. Di
                                                            chuyển
                                                            bằng tàu về khách sạn</div>
                                                        <!--end::Text-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">8h20
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-success fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Content-->
                                                        <div class="timeline-content d-flex">
                                                            <span class="fw-bolder text-gray-800 ps-3">Khách nhận phòng
                                                                tại khách
                                                                sạn</span>
                                                        </div>
                                                        <!--end::Content-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">9h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">
                                                            <div class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                Bắt đầu khám phá
                                                                đảo BÌNH HƯNG – Vương quốc tôm hùm</div>
                                                            <div class="d-flex align-items-center collapsible toggle mb-0 collapsed"
                                                                data-bs-toggle="collapse" data-bs-target="#kt_job_3_3"
                                                                aria-expanded="false">
                                                                <!--begin::Icon-->
                                                                <div
                                                                    class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen036.svg-->
                                                                    <span
                                                                        class="svg-icon toggle-on svg-icon-primary svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="6.0104" y="10.9247" width="12"
                                                                                height="2" rx="1"
                                                                                fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
                                                                    <span class="svg-icon toggle-off svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="10.8891" y="17.8033"
                                                                                width="12" height="2"
                                                                                rx="1"
                                                                                transform="rotate(-90 10.8891 17.8033)"
                                                                                fill="black"></rect>
                                                                            <rect x="6.01041" y="10.9247"
                                                                                width="12" height="2"
                                                                                rx="1" fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                </div>
                                                                <!--end::Icon-->
                                                                <!--begin::Title-->
                                                                <div
                                                                    class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                    Bao gồm</div>
                                                                <!--end::Title-->
                                                            </div>
                                                            <div id="kt_job_3_3" class="fs-6 ms-1" style="">
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tàu đáy
                                                                            kính đưa khách
                                                                            đi tham quan vịnh Đá Vách, Hang Sâu
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tắm
                                                                            biển tại bãi Cây Me
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Lặn
                                                                            ngắm san hô tại bãi
                                                                            Lớn hoặc bãi Hòn Sam (có đầy đủ thiết bị như
                                                                            phao và
                                                                            kính lặn…)</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                            </div>

                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">11h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-primary fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">
                                                            <div class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                Quay về bè nổi ăn
                                                                trưa</div>
                                                            <div class="d-flex align-items-center collapsible toggle mb-0 collapsed"
                                                                data-bs-toggle="collapse" data-bs-target="#thucdon"
                                                                aria-expanded="false">
                                                                <!--begin::Icon-->
                                                                <div
                                                                    class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen036.svg-->
                                                                    <span
                                                                        class="svg-icon toggle-on svg-icon-primary svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="6.0104" y="10.9247" width="12"
                                                                                height="2" rx="1"
                                                                                fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
                                                                    <span class="svg-icon toggle-off svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="10.8891" y="17.8033"
                                                                                width="12" height="2"
                                                                                rx="1"
                                                                                transform="rotate(-90 10.8891 17.8033)"
                                                                                fill="black"></rect>
                                                                            <rect x="6.01041" y="10.9247"
                                                                                width="12" height="2"
                                                                                rx="1" fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                </div>
                                                                <!--end::Icon-->
                                                                <!--begin::Title-->
                                                                <div
                                                                    class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                    Thực đơn gồm
                                                                </div>
                                                                <!--end::Title-->
                                                            </div>
                                                            <div id="thucdon" class="fs-6 ms-1" style="">
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Mực hấp
                                                                            cuốn bánh tráng
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tôm ram
                                                                            thịt
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cá
                                                                            chiên xoài bằm</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Hàu sữa
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cá kho
                                                                            tộ</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Lẩu hải
                                                                            sản ăn bún
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cơm
                                                                            trắng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                            </div>

                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">12h20
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bold text-gray-800 ps-3">Quay
                                                            về khách sạn và
                                                            nghỉ
                                                            ngơi
                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">14h20
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-primary fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Text-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">Tham
                                                            quan Chùa Long
                                                        </div>
                                                        <!--end::Text-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">15h20
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bold text-gray-800 ps-3">Tham
                                                            quan bãi Đá Trứng
                                                            – với
                                                            những
                                                            hòn đá to tròn đẹp</div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">17h20
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-success fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">
                                                            <div class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                Quay về khách sạn
                                                                tắm rửa ,nghỉ nghơi và ăn tối</div>
                                                            <div class="d-flex align-items-center collapsible toggle mb-0 collapsed"
                                                                data-bs-toggle="collapse" data-bs-target="#thucdon2"
                                                                aria-expanded="false">
                                                                <!--begin::Icon-->
                                                                <div
                                                                    class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen036.svg-->
                                                                    <span
                                                                        class="svg-icon toggle-on svg-icon-primary svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="6.0104" y="10.9247" width="12"
                                                                                height="2" rx="1"
                                                                                fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
                                                                    <span class="svg-icon toggle-off svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="10.8891" y="17.8033"
                                                                                width="12" height="2"
                                                                                rx="1"
                                                                                transform="rotate(-90 10.8891 17.8033)"
                                                                                fill="black"></rect>
                                                                            <rect x="6.01041" y="10.9247"
                                                                                width="12" height="2"
                                                                                rx="1" fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                </div>
                                                                <!--end::Icon-->
                                                                <!--begin::Title-->
                                                                <div
                                                                    class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                    Thực đơn gồm
                                                                </div>
                                                                <!--end::Title-->
                                                            </div>
                                                            <div id="thucdon2" class="fs-6 ms-1" style="">
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tôm hùm
                                                                            1con/người
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Mực
                                                                            nướng/ mực chiên
                                                                            giòn
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Ghẹ hấp
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Sò
                                                                            nướng mỡ hành</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cháo
                                                                            hải sản</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cơm
                                                                            chiên trứng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cầu gai
                                                                            nướng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cá
                                                                            nướng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">3 loại
                                                                            ốc hấp</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tráng
                                                                            miệng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                            </div>

                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <span class="badge badge-square badge-primary"
                                                        style="padding:5px;">NGÀY 2</span>
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">6h20
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-warning fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Text-->
                                                        <div class="fw-bolder timeline-content text-gray-800 ps-3">Ăn
                                                            sáng + café</div>
                                                        <!--end::Text-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">8h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-success fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Content-->
                                                        <div class="timeline-content d-flex">
                                                            <span class="fw-bolder text-gray-800 ps-3">Tiếp tục hành
                                                                trình khám phá và
                                                                tắm
                                                                biển</span>
                                                        </div>
                                                        <!--end::Content-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">10h20
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">
                                                            Quay về khách sạn trả phòng
                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">11h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-primary fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Text-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">Quay
                                                            về bè nổi ăn
                                                            trưa
                                                        </div>
                                                        <!--end::Text-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">11h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">
                                                            <div class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                Quay về khách sạn
                                                                tắm rửa ,nghỉ nghơi và ăn tối</div>
                                                            <div class="d-flex align-items-center collapsible toggle mb-0 collapsed"
                                                                data-bs-toggle="collapse" data-bs-target="#thucdon3"
                                                                aria-expanded="false">
                                                                <!--begin::Icon-->
                                                                <div
                                                                    class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen036.svg-->
                                                                    <span
                                                                        class="svg-icon toggle-on svg-icon-primary svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="6.0104" y="10.9247" width="12"
                                                                                height="2" rx="1"
                                                                                fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
                                                                    <span class="svg-icon toggle-off svg-icon-1">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="24" height="24"
                                                                            viewBox="0 0 24 24" fill="none">
                                                                            <rect opacity="0.3" x="2" y="2"
                                                                                width="20" height="20"
                                                                                rx="5" fill="black"></rect>
                                                                            <rect x="10.8891" y="17.8033"
                                                                                width="12" height="2"
                                                                                rx="1"
                                                                                transform="rotate(-90 10.8891 17.8033)"
                                                                                fill="black"></rect>
                                                                            <rect x="6.01041" y="10.9247"
                                                                                width="12" height="2"
                                                                                rx="1" fill="black"></rect>
                                                                        </svg>
                                                                    </span>
                                                                    <!--end::Svg Icon-->
                                                                </div>
                                                                <!--end::Icon-->
                                                                <!--begin::Title-->
                                                                <div
                                                                    class="text-gray-800 fw-bolder cursor-pointer mb-0">
                                                                    Thực đơn gồm
                                                                </div>
                                                                <!--end::Title-->
                                                            </div>
                                                            <div id="thucdon3" class="fs-6 ms-1" style="">
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Canh
                                                                            chua cá biển
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Mực xào
                                                                            chua ngọt
                                                                        </div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cá
                                                                            chiên sốt cà</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Trứng
                                                                            chiên</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cá kho
                                                                            tộ</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tôm kho
                                                                            thịt</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Cơm
                                                                            trắng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                                <!--begin::Item-->
                                                                <div class="mb-4">
                                                                    <!--begin::Item-->
                                                                    <div class="d-flex align-items-center ps-10 mb-n1">
                                                                        <!--begin::Bullet-->
                                                                        <span class="bullet me-3"></span>
                                                                        <!--end::Bullet-->
                                                                        <!--begin::Label-->
                                                                        <div class="text-gray-700 fw-bold fs-7">Tráng
                                                                            miệng</div>
                                                                        <!--end::Label-->
                                                                    </div>
                                                                    <!--end::Item-->
                                                                </div>
                                                                <!--end::Item-->
                                                            </div>

                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                    <!--begin::Item-->
                                                    <div class="timeline-item">
                                                        <!--begin::Label-->
                                                        <div class="timeline-label fw-bolder text-gray-800 fs-6">12h00
                                                        </div>
                                                        <!--end::Label-->
                                                        <!--begin::Badge-->
                                                        <div class="timeline-badge">
                                                            <i class="fa fa-genderless text-danger fs-1"></i>
                                                        </div>
                                                        <!--end::Badge-->
                                                        <!--begin::Desc-->
                                                        <div class="timeline-content fw-bolder text-gray-800 ps-3">Tàu
                                                            chở quý khách
                                                            quay về đất
                                                            liền .Kết thúc tour
                                                        </div>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Item-->
                                                </div>
                                                <!--end::Text-->
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

                <!--end::Heading-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::How It Works Section-->
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $attributes = $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $component = $__componentOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/pages/lichtrinh.blade.php ENDPATH**/ ?>