<!--begin::Scrolltop-->
<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
    <?php echo theme()->getSvgIcon("icons/duotune/arrows/arr066.svg"); ?>

</div>
<!--end::Scrolltop-->
<?php /**PATH /var/www/resources/views/layout/demo1/_scrolltop.blade.php ENDPATH**/ ?>