<div class="main">
    <div class="container">
      <?php echo e($slot); ?>

    </div>
  </div><?php /**PATH /var/www/resources/views/admin/layout/_content.blade.php ENDPATH**/ ?>