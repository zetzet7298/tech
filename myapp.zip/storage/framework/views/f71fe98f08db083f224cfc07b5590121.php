<?php if (isset($component)) { $__componentOriginal7442783a15dff2b0d32f2947a462c2e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2 = $attributes; } ?>
<?php $component = App\View\Components\BaseLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            var uriValue = $('input[name="uri"]').val();
            if (uriValue != '') {
                // Lấy vị trí top của phần tử có ID cụ thể
                var targetOffset = $(`#${uriValue}`).offset().top;

                // Cuộn trang đến vị trí của phần tử với hiệu ứng animate
                $('html, body').animate({
                    scrollTop: targetOffset
                }, 1); // Thời gian cuộn (miliseconds)
            }

        });
    </script>
<?php $__env->stopSection(); ?>
<!--begin::Main-->
<input name="uri" type="hidden" value="<?php echo e($uri); ?>" />
<div class="d-flex flex-column flex-root py-5" id="cam-nang-du-lich-dao-binh-hung">
    <div class="mb-lg-n15 position-relative z-index-2">
        <!--begin::Container-->
        <div class="container">
            <!--begin::Card-->
            <div class="card" style="filter: drop-shadow(0px 0px 40px rgba(68, 81, 96, 0.08))">
                <!--begin::Card body-->
                <div class="card-body p-lg-20">
                    <p style="margin-left:0px;text-align:justify;"><strong>Đảo Bình Hưng</strong> là một đảo nhỏ thuộc xã
                        Cam Bình, Thành phố Cam Ranh, Nha Trang, Khánh Hoà.&nbsp;Đảo còn có tên gọi khác là hòn Tý hay
                        hòn Chút.&nbsp;Đến đây bạn sẽ tận mắt nhìn thấy những bãi cát trắng mịn, màu nước biển trong
                        xanh. Bờ biển Bình Hưng thoai thoải, cách xa bờ biển chỉ chừng 10m là bạn sẽ được nhìn thấy san
                        hô dưới mặt nước xanh trong.</p>
                    <blockquote>
                        <p style="margin-left:0px;text-align:justify;"><i>Xem thêm: </i><a target="_blank"
                                rel="noopener noreferrer"
                                href="https://hongnhanbinhhung.com/lich-trinh-binh-hung"><i><strong>Lịch trình du lịch Bình Hưng</strong></i></a></p>
                    </blockquote>
                    <h2 style="margin-left:0px;text-align:justify;" class="fs-1 fw-boldest">Du lịch đảo Bình Hưng Cam
                        Ranh, Nha Trang</h2>
                    <p style="margin-left:0px;">Bình Hưng là một mảnh ghép không thể thiếu trong bức tranh tứ bình mà
                        thiên nhiên đặc biệt ưu đãi cho Cam Ranh, Nha Trang. Nằm ẩn dưới chân đèo trên cung đường biển
                        Vĩnh Hy – Bình Tiên, hòn đảo xinh đẹp hiện ra với hang đá nước ngọt rất đặc biệt, làn nước trong
                        xanh nhìn rõ những dải san hô tuyệt đẹp bên dưới, bãi biển thoai thoải với nhiều tảng đá hình
                        thù, màu sắc sinh động, kiểu dáng phong phú, có những tảng đá còn phủ kín rêu xanh rất đẹp nữa.
                        Du khách sẽ được thưởng thức những món hải sản tươi ngon nhất vừa được đánh bắt từ biển về,
                        ngoài ra còn món tôm hùm trứ danh bởi nơi này còn nổi tiếng với nghề nuôi tôm hùm.</p>
                    <img src="assets/media/camnang/1.jpg" alt="Bình Hưng xinh đẹp" class="img-fluid">

                    <p style="margin-left:0px;"><i>Nước biển trong xanh mang vẻ đẹp thiên nhiên</i></p>
                    <p style="margin-left:0px;text-align:justify;">Những ngôi nhà nho nhỏ đơn sơ trên <strong>đảo Bình
                            Hưng</strong> san sát nhau, một bên có núi rừng, một bên là mặt biển xanh trong, trên mặt
                        biển có những chiếc tàu thuyền đánh bắt cá của ngư dân. Nhìn trên cao đảo như một bức tranh có
                        kết cấu hài hoà được vẽ nên từ đôi bàn tay của một nghệ nhân nổi tiếng.</p>
                    <img src="assets/media/camnang/2.jpg" alt="Bức tranh Bình Hưng tuyệt đẹp" class="img-fluid">
                    <p style="margin-left:0px;"><i>“Bức tranh” sơn thủy hữu tình tuyệt đẹp</i></p>
                    <h2 style="margin-left:0px;text-align:justify;"><span style="font-size:26.5493px;"><strong>Cách đi
                                đến đảo</strong></span></h2>
                    <p style="margin-left:0px;text-align:justify;">Có nhiều cách đi <strong>du lịch Bình Hưng</strong>
                        từ các thành phố lớn như Hà Nội, thành phố Hồ Chí Minh, Đà Nẵng, bạn có thể đi chuyển đến thành
                        phố Cam Ranh bằng nhiều phương tiện như xe máy, ô tô, xe khách, tàu lửa, máy bay.</p>
                    <ul>
                        <li>
                            <p style="margin-left:0px;text-align:justify;">Nếu bạn di chuyển bằng máy bay: Bạn chọn
                                tuyến đến sân bay Cam Ranh</p>
                        </li>
                        <li>
                            <p style="margin-left:0px;text-align:justify;">Nếu bạn di chuyển bằng tàu lửa: Bạn mua vé
                                đến điểm dừng chân Cam Ranh.</p>
                        </li>
                        <li>
                            <p style="margin-left:0px;text-align:justify;">Nếu bạn di chuyển bằng xe khách: Chọn tuyến
                                bến xe Miền Đông (Sài Gòn) đến bến xe Cam Ranh.</p>
                        </li>
                        <li>
                            <p style="margin-left:0px;text-align:justify;">Nếu bạn phượt bằng xe máy:</p>
                        </li>
                    </ul>
                    <p style="margin-left:0px;text-align:justify;">+ Di chuyển từ thành phố Cam Ranh theo đường quốc lộ
                        1A hướng về Ninh Thuận, tiếp tục đi theo tuyến đường Bình Lập – Bình Tiên khoảng 15 km là đến
                        Bãi Kinh – Bình Hưng. Từ Bãi Kinh, đi thuyền qua đảo khoảng 10 phút đến Bình Hưng.</p>
                    <p style="margin-left:0px;text-align:justify;">+ Du lịch Phan Rang rồi di chuyển từ thành phố Phan
                        Rang chạy xe sang đảo theo đường quốc lộ 702 hướng đi vịnh Vĩnh Hy khoảng 57 km, tới ngã ba Vĩnh
                        Hy rẽ bên trái đi theo con đường mới thêm 13 km nữa là đến Bãi Kinh. Từ Bãi Kinh, đi thuyền qua
                        đảo khoảng 10 phút đến Bình Hưng.</p>
                    <h2 style="margin-left:0px;"><span style="font-size:26.5493px;"><strong>Di chuyển trên đảo bằng
                                phương tiện gì?</strong></span></h2>
                    <h3 style="margin-left:0px;"><span style="font-size:26.5493px;"><strong>Đi bộ</strong></span></h3>
                    <p style="margin-left:0px;">Do diện tích của đảo tương đối nhỏ nên bạn hoàn toàn có thể di chuyển
                        bằng cách đi bộ để khám phá trọn vẹn mọi hang cùng ngõ ngách trên đảo nhé!</p>
                    <h3 style="margin-left:0px;"><span style="font-size:26.5493px;"><strong>Đi thuyền</strong></span>
                    </h3>
                    <p style="margin-left:0px;">Vì là hòn đảo riêng biệt nên nếu bạn muốn tham quan những bè nuôi hải
                        sản của ngư dân địa phương hay thưởng thức hải sản tươi sống ngay tại điểm nuôi thì việc di
                        chuyển bằng thuyền là cần thiết hơn cả. Ngoài ra còn có những chiếc thuyền có đáy làm từ kính
                        trong suốt để bạn vừa du ngoạn vừa ngắm nhìn rặng sạn hô bên dưới một cách chân thực nhất.</p>
                    <img src="assets/media/camnang/3.jpg" class="img-fluid"
                        alt="Nếu muốn thăm tận nơi bè nuôi hải sản của ngư dân thì chắc chắn bạn phải di chuyển bằng thuyền đó!">
                    <p style="margin-left:0px;"><i>Nếu muốn thăm tận nơi bè nuôi hải sản của ngư dân thì chắc chắn bạn
                            phải di chuyển bằng thuyền đó!</i></p>
                    <h3 style="margin-left:0px;"><span style="font-size:26.5493px;"><strong>Đi xe máy</strong></span>
                    </h3>
                    <p style="margin-left:0px;">Nếu muốn tiết kiệm thời gian hay không thích đi bộ thì bạn có thể thuê
                        xe máy ở các nhà nghỉ, nhà trọ ngay trên đảo với giá khá hợp lý từ 120.000 – 150.000 đồng/ngày.
                    </p>
                    <h2 style="margin-left:0px;text-align:justify;"><span style="font-size:26.5493px;"><strong>Ngủ qua
                                đêm trên đảo Bình Hưng ở đâu?</strong></span></h2>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;text-align:justify;"><span
                                    style="font-size:20.5493px;"><strong><u>Dịch vụ nhà nghỉ, khách sạn Hồng
                                            Nhàn</u></strong></span></h3>
                        </li>
                    </ul>
                    <blockquote>
                        <p style="margin-left:0px;text-align:justify;"><i>Xem thêm: </i><a target="_blank"
                                rel="noopener noreferrer"
                                href="https://hongnhanbinhhung.com/khach-san-binh-hung"><i><strong>Khách sạn Hồng Nhàn Bình Hưng</strong></i></a></p>
                    </blockquote>
                    <p style="margin-left:0px;text-align:justify;">Khách sạn mới mẻ, sang trọng, đầy đủ tiện nghi, phía
                        trước là view biển. Vị trí phù hợp để ngắm nhìn toàn bộ khung cảnh đảo Bình Hưng</p>
                    <img src="assets/media/camnang/4.jpg" class="img-fluid"
                        alt="Dịch vụ khách sạn là lựa chọn cho ai thích sự sang trọng và đầy đủ tiện nghi">
                    <p style="margin-left:0px;"><i>Dịch vụ khách sạn là lựa chọn cho ai thích sự sang trọng và đầy đủ
                            tiện nghi</i></p>
                    <img src="assets/media/camnang/6.jpg" class="img-fluid"
                        alt="Dẽ dàng ngắm nhìn toàn bộ khung cảnh đảo Bình Hưng">
                    <p style="margin-left:0px;"><i>Dẽ dàng ngắm nhìn toàn bộ khung cảnh đảo Bình Hưng</i></p>
                    <img src="assets/media/camnang/5.jpg" class="img-fluid"
                        alt="Bạn liên hệ chị Hồng (094 270 4480) để dùng dịch vụ khách sạn nhé">
                    <p style="margin-left:0px;"><i>Bạn liên hệ chị Hồng (094 270 4480) để dùng dịch vụ khách sạn nhé</i>
                    </p>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;text-align:justify;"><span
                                    style="font-size:26.5493px;"><strong><u>Cắm trại trên biển</u></strong></span></h3>
                        </li>
                    </ul>
                    <p style="margin-left:0px;text-align:justify;">Mang lều trại đến dựng trên biển, làm tiệc nướng buổi
                        tối, trò chuyện cùng bạn bè và ngủ trên biển vào buổi tối thì còn gì tuyệt bằng. Vì thế, đó là
                        một lựa chọn được nhiều bạn trẻ ưa chuộng.</p>
                    <img src="assets/media/camnang/camtrai.jpg" class="img-fluid"
                        alt="Cắm trại qua đêm trên biển là hình thức được nhiều bạn trẻ, nhóm phượt lựa chọn">
                    <p style="margin-left:0px;"><i>Cắm trại qua đêm trên biển là hình thức được nhiều bạn trẻ, nhóm
                            phượt lựa chọn (Ảnh ST)</i></p>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;text-align:justify;"><span
                                    style="font-size:26.5493px;"><strong><u>Ngủ tại nhà bè</u></strong></span></h3>
                        </li>
                    </ul>
                    <p style="margin-left:0px;text-align:justify;">Du khách đến <strong>đảo Bình Hưng</strong> có thể
                        ngủ lại trên nhà bè của ngư dân, cảm giác được lênh đênh trên biển nghe tiếng sóng vỗ nhẹ nhàng,
                        dịu êm dễ dàng đưa bạn vào giấc ngủ ngon sau chuyến đi đường dài đuối sức. Buổi sáng, bạn có thể
                        lắng nghe tiếng khua thuyền, chèo thúng của ngư dân đánh bắt cá và ngắm bình minh lên.</p>
                    <p style="margin-left:0px;">Nếu thích loại hình này thì ghé nhà bè Hồng Nhàn nhé!</p>
                    <img src="assets/media/camnang/7.jpg" class="img-fluid" alt="Nhà bè ở đảo Bình Hưng">
                    <p style="margin-left:0px;"><i>Nhà bè ở đảo Bình Hưng</i></p>
                    <h2 style="margin-left:0px;text-align:justify;"><span style="font-size:26.5493px;"><strong>Đến đảo
                                Bình Hưng thì đi đâu chơi?</strong></span></h2>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;text-align:justify;"><span
                                    style="font-size:26.5493px;"><strong><u>Biển Bình Tiên</u></strong></span></h3>
                        </li>
                    </ul>
                    <p style="margin-left:0px;text-align:justify;">Từ Bình Hưng nhìn sang bạn có thể thấy biển Bình Tiên
                        trầm mặc một màu xanh ngọc tuyệt đẹp như một bức tranh hữu tình. Cách biển Bình Tiên chỉ 10 phút
                        đi tàu. Đến biển Bình Tiên bạn có thể dạo biển, tham quan suối nước ngọt Núi Chúa, đánh bắt cá
                        dưới suối và nằm trên mỏm đá phơi nắng như một vị thi sĩ đang chiêm nghiệm sự đời. Hoặc cùng bạn
                        bè tự sướng mải mê, thỏa sức trong khung cảnh thiên nhiên tươi đẹp này.</p>
                    <img src="assets/media/camnang/8.jpg" class="img-fluid"
                        alt="Núi non hùng vỹ bao trùm biển Bãi Tiên thêm phần hoang sơ">
                    <p style="margin-left:0px;"><i>Núi non hùng vỹ bao trùm biển Bãi Tiên thêm phần hoang sơ</i></p>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;text-align:justify;"><span
                                    style="font-size:26.5493px;"><strong><u>Bãi Kinh</u></strong></span></h3>
                        </li>
                    </ul>
                    <p style="margin-left:0px;text-align:justify;">Bãi Kinh là nơi cho du khách qua lại giữa đảo và đất
                        liền. Nếu từ các Thành phố xuống, bạn gửi xe rồi tham quan, tắm biển, vui chơi tại Bãi Kinh. Còn
                        nếu từ đảo Bình Hưng sang thì bạn đi tàu qua bãi, trên Bãi Kinh có cho thuê lều cắm trại tại
                        bãi.</p>
                    <img src="assets/media/camnang/9.jpg" class="img-fluid"
                        alt="Bãi biển ở đây là trong xanh nhất cũng như bãi rất cạn nên gia đình có trẻ nhỏ có thể vui chơi thỏa thích">
                    <p style="margin-left:0px;"><i>Bãi biển ở đây là trong xanh nhất cũng như bãi rất cạn nên gia đình
                            có trẻ nhỏ có thể vui chơi thỏa thích</i></p>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;"><span style="font-size:26.5493px;"><strong><u>Bãi Nước
                                            Ngọt</u></strong></span></h3>
                        </li>
                    </ul>
                    <p style="margin-left:0px;">Được bao bọc xung quanh bởi những dãy núi cao ở ba phía,&nbsp;dòng nước
                        trong xanh vô cùng, nơi đây là điểm đến hấp dẫn du khách nhất trên đảo. Bạn cũng có thể cắm trại
                        qua đêm và thức dậy chào đón ánh bình minh đẹp mê hồn ở bãi biển này đấy.</p>
                    <img src="assets/media/camnang/10.jpg" class="img-fluid"
                        alt="Ngoài tắm biển bạn có thể khám phá hang nước ngọt ngay gần đó">
                    <p style="margin-left:0px;"><i>Ngoài tắm biển bạn có thể khám phá hang nước ngọt ngay gần đó</i>
                    </p>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;"><span style="font-size:26.5493px;"><strong><u>Bãi Cây
                                            Me</u></strong></span></h3>
                        </li>
                    </ul>
                    <p style="margin-left:0px;">Dù nằm trên <strong>đảo Bình Hưng</strong> nhưng muốn đến bãi Cây Me
                        thì cần phải đi bằng tàu vì ở đây không có đường đi bộ đến bãi. Bạn có thể tha hồ check-in với
                        tảng đá ở ở giữa bãi, với làn nước trong xanh giống như nước hồ bơi, trong đến mức 5m vẫn có thể
                        nhìn thấy đáy đó.</p>
                    <img src="assets/media/camnang/11.jpg" class="img-fluid"
                        alt="Nước biển xanh như ngọc ở Bãi cây me">
                    <p style="margin-left:0px;"><i>Nước biển xanh như ngọc ở Bãi cây me</i></p>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;"><span style="font-size:26.5493px;"><strong><u>Bãi Đá
                                            Trứng</u></strong></span></h3>
                        </li>
                    </ul>
                    <p style="margin-left:0px;">Bạn sẽ ngạc nhiên nếu lần đầu đặt chân tới đây bởi những hòn đá to,
                        tròn giống như trứng của khung long vậy đó. Nơi đây chủ yếu ghé để tham quan và chụp ảnh, không
                        tắm được bởi cả bãi đều là đá thôi à. Dù vậy thì khung cảnh đẹp của nơi này cũng khiến bạn thích
                        mê cho xem.</p>
                    <img src="assets/media/camnang/12.jpg" class="img-fluid"
                        alt="Ngắm hoàng hôn nơi đây thì còn gì tuyệt vời hơn">
                    <p style="margin-left:0px;"><i>Ngắm hoàng hôn nơi đây thì còn gì tuyệt vời hơn</i></p>
                    <ul>
                        <li>
                            <h3 style="margin-left:0px;"><span style="font-size:26.5493px;"><strong><u>Vịnh Đá
                                            Dách</u></strong></span></h3>
                        </li>
                    </ul>
                    <p style="margin-left:0px;">Vịnh Đá Dách bao xung quanh toàn là nước biển xanh thăm thẳm, rất sâu
                        và tập trung những vách đá cao 40-50m với vô vàn vết cắt từ mẹ thiên nhiên lên các mặt đá tạo
                        nên vẻ đẹp hoang sơ kỳ bí cho nơi này. Check-in ở đây thì cứ phải gọi là đẹp ngất ngây và chất
                        lừ luôn đấy.</p>
                    <img src="assets/media/camnang/13.jpg" class="img-fluid"
                        alt="Nơi đây tập trung những vách đá cao từ 40 đến 50m với rất nhiều các vết (trông như được) cắt bằng cưa lên bề mặt đá.">
                    <p style="margin-left:0px;"><i>Nơi đây tập trung những vách đá cao từ 40 đến 50m với rất nhiều các
                            vết (trông như được) cắt bằng cưa lên bề mặt đá.</i></p>
                    <h2 style="margin-left:0px;text-align:justify;"><span style="font-size:26.5493px;"><strong>Điểm
                                danh các món ăn không thể bỏ qua tại đảo Bình Hưng</strong></span></h2>
                    <p style="margin-left:0px;text-align:justify;">Từ khi được nhiều du khách biết đến, đảo đã có những
                        quán xá bán rất nhiều các loại hải sản nên bạn hãy yên tâm là bạn sẽ được no bụng và cảm thấy
                        thỏa mãn với ẩm thực biển nơi đây.</p>
                    <img src="assets/media/camnang/14.jpg" class="img-fluid"
                        alt="Ăn phủ phê với những món ăn trên bàn siêu chất lượng">
                    <p style="margin-left:0px;"><i>Ăn phủ phê với những món ăn trên bàn siêu chất lượng</i></p>
                    <img src="assets/media/camnang/15.jpg" class="img-fluid"
                        alt="Ăn phủ phê với những món ăn trên bàn siêu chất lượng">
                    <p style="margin-left:0px;"><i>Ăn phủ phê với những món ăn trên bàn siêu chất lượng</i></p>
                    <img src="assets/media/camnang/16.jpg" class="img-fluid"
                        alt="Ăn phủ phê với những món ăn trên bàn siêu chất lượng">
                    <p style="margin-left:0px;"><i>Ăn phủ phê với những món ăn trên bàn siêu chất lượng</i></p>
                    <img src="assets/media/camnang/17.jpg" class="img-fluid"
                        alt="Ăn phủ phê với những món ăn trên bàn siêu chất lượng">
                    <p style="margin-left:0px;"><i>Ăn phủ phê với những món ăn trên bàn siêu chất lượng</i></p>
                    <p style="margin-left:0px;text-align:justify;">Trên đây là những <strong>kinh nghiệm du lịch đảo
                            Bình Hưng</strong> để bạn thuận tiện hơn khi đến du lịch, bạn không chỉ được tận hưởng không
                        khí trong lành của bãi biển hoang sơ, mà còn được trải nghiệm du lịch nhiều nơi trong chuyến
                        phượt&nbsp; Bình Hưng này và được trở về với cuộc sống gần gũi với con người, thiên nhiên, cuộc
                        sống sẽ trôi chầm chậm, và đó là những khoảnh khắc lắng lòng trong cuộc sống của bạn.</p>
                </div>
            </div>
        </div>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $attributes = $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $component = $__componentOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/pages/camnang.blade.php ENDPATH**/ ?>