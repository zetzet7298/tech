<?php

namespace Database\Seeders;

use App\Core\AccountConstant;
use App\Models\Income;
use App\Models\Transfer;
use App\Models\User;
use App\Models\UserInfo;
use Faker\Generator;
use Faker\Provider\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use TCG\Voyager\Models\Role;
use Illuminate\Support\Str;
class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(Generator $faker)
    {
        $demoUser = User::create([
            //'id' => Str::uuid()->toString(),
            'name'        => 'admin',
            'email'             => 'admin@admin.com',
            'password'          => Hash::make('admin'),
        ]);
    }
}
